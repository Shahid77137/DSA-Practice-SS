package com.masaischool.dto;

public class StudentImpl implements Student {
	private int rollNo;
	private String name;
	private String email;
	private double xPer;
	private String state;
	
	public StudentImpl() {
		super();
	}
	public StudentImpl(int rollNo, String name, String email, double xPer, String state) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.email = email;
		this.xPer = xPer;
		this.state = state;
	}
	@Override
	public int getRollNo() {
		return rollNo;
	}
	@Override
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	@Override
	public String getName() {
		return name;
	}
	@Override
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String getEmail() {
		return email;
	}
	@Override
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public double getxPer() {
		return xPer;
	}
	@Override
	public void setxPer(double xPer) {
		this.xPer = xPer;
	}
	@Override
	public String getState() {
		return state;
	}
	@Override
	public void setState(String state) {
		this.state = state;
	}
	
	@Override
	public String toString() {
		return "Roll No = " + rollNo + ", Name = " + name + ", Email = " + email + ", X Percentage = " + xPer + ", state = "
				+ state + "]";
	}
	
	
}
