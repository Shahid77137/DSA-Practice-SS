package com.masaischool.dto;

public interface Student {
	public int getRollNo();
	public void setRollNo(int rollNo);
	public String getName();
	public void setName(String name);
	public String getEmail();
	public void setEmail(String email);
	public double getxPer();
	public void setxPer(double xPer);
	public String getState();
	public void setState(String state);
}
