package com.masaischool.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

import com.masaischool.dao.StudentDAO;
import com.masaischool.dao.StudentDAOImpl;
import com.masaischool.dto.Student;
import com.masaischool.dto.StudentImpl;
import com.masaischool.exception.NoRecordFoundException;
import com.masaischool.exception.SomeThingWrongException;

public class UIMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StudentDAO studentDAO = new StudentDAOImpl();
		int choice = 0;
		do {
			System.out.println("1. Add Student\n2. View Student\n3. Update Student\n4. Delete Student\n0. Exit");
			System.out.print("Enter selection ");
			choice = sc.nextInt();
			if(choice == 1) {
				try{
					studentDAO.addStudent(new StudentImpl(14, "TYU", "tyu@ms.in", 58.36, "Raj"));					
				}catch(SomeThingWrongException ex) {
					System.out.println(ex);
				}

			}else if(choice == 2) {
				try {
					List<Student> list = studentDAO.getstudentList();
					for(Student st: list) {
						System.out.println(st);
					}
				}catch(SomeThingWrongException | NoRecordFoundException ex) {
					System.out.println(ex);
				}
			}else if(choice == 3) {
				
			}else if(choice == 4) {
				
			}
		}while(choice != 0);
		System.out.println("Thanks for using services, visit again");
		sc.close();
	}
}
