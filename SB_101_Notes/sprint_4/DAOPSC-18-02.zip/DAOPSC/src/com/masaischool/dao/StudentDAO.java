package com.masaischool.dao;
import java.util.List;

import com.masaischool.dto.Student;
import com.masaischool.exception.NoRecordFoundException;
import com.masaischool.exception.SomeThingWrongException;

public interface StudentDAO {
	void addStudent(Student student) throws SomeThingWrongException;
	void updateStudent(Student student) throws SomeThingWrongException;
	void deleteStudent(int rollNo) throws SomeThingWrongException;
	List<Student> getstudentList() throws SomeThingWrongException, NoRecordFoundException;
}
