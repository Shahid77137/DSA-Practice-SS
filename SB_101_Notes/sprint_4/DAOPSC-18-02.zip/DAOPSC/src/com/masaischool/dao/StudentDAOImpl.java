package com.masaischool.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.masaischool.dto.Student;
import com.masaischool.dto.StudentImpl;
import com.masaischool.exception.NoRecordFoundException;
import com.masaischool.exception.SomeThingWrongException;

public class StudentDAOImpl implements StudentDAO {

	@Override
	public void addStudent(Student student) throws SomeThingWrongException {
		Connection connection = null;
		try {
			connection = DbUtils.connectToDatabase();
			//write code to insert record in the table
			String INSERT_QUERY = "INSERT INTO st VALUES (?, ?, ?, ?, ?)";
			PreparedStatement ps = connection.prepareStatement(INSERT_QUERY);
			
			//stuff the input data in query
			ps.setInt(1, student.getRollNo());
			ps.setString(2, student.getName());
			ps.setString(3, student.getEmail());
			ps.setDouble(4, student.getxPer());
			ps.setString(5, student.getState());
			
			//execute update statement
			System.out.println(ps.executeUpdate() > 0?"Student added":"Not able to add student");			
		}catch(SQLException ex) {
			//log the exception here for debugging in future
			throw new SomeThingWrongException();
		}finally {
			try {
				DbUtils.closeConnection(connection);				
			}catch(SQLException ex) {
				
			}
		}
	}

	@Override
	public void updateStudent(Student student) throws SomeThingWrongException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteStudent(int rollNo) throws SomeThingWrongException {
		// TODO Auto-generated method stub
		
	}
	
	private boolean isResultSetEmpty(ResultSet rs) throws SQLException {
		return (!rs.isBeforeFirst() && rs.getRow() == 0)?true:false;
	}
	
	private List<Student> getStudentListFromResultSet(ResultSet resultSet) throws SQLException{
		List<Student> list = new ArrayList<>();
		while(resultSet.next()) {
			//Create an object of Employee
			Student student = new StudentImpl();
			student.setRollNo(resultSet.getInt("rollNo"));
			student.setName(resultSet.getString("name"));
			student.setEmail(resultSet.getString("email"));
			student.setxPer(resultSet.getDouble("x_per"));
			student.setState(resultSet.getString("state"));
			list.add(student);
		}
		return list;
	}

	@Override
	public List<Student> getstudentList() throws SomeThingWrongException, NoRecordFoundException {
		Connection connection = null;
		List<Student> studentList = null;
		try {
			connection = DbUtils.connectToDatabase();
			String SELECT_QUERY = "SELECT * FROM st";
			PreparedStatement ps = connection.prepareStatement(SELECT_QUERY);
			ResultSet rs = ps.executeQuery();
			if(isResultSetEmpty(rs)) {
				throw new NoRecordFoundException("No Student Found");
			}else {
				studentList = getStudentListFromResultSet(rs);
			}
		}catch(SQLException ex) {
			System.out.println(ex);
		}
		return studentList;
	}

}
