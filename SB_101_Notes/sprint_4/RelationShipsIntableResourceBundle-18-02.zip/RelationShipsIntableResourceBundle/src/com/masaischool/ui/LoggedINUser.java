package com.masaischool.ui;

public class LoggedINUser {
	public static int loggedInUserId;
}
